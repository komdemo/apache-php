## referto https://hub.docker.com/_/php
#docker pull php:7.4-apache-bullseye
## create network
docker network create  ginet
## Run http server
docker run -d -p 8100:80 --name my-apache-php-app --network ginet -v ${PWD}/www/:/var/www/html php:7.2-apache
#run custom add mysqli ext version
docker run -d -p 8100:80 --name my-apache-php-app --network ginet -v ${PWD}/www/:/var/www/html myphp:v1

## mysql section#
#docker pull mysql:5.5.49

# rundatabase server in same network
docker run --name mysqldb -e MYSQL_ROOT_PASSWORD=Pw1SuperSecret --network ginet -d mysql:5.5.49

# run phpadmin (Option)
docker run --name phpmyadmin -d -e PMA_HOST=mysqldb -p 8180:80 --network ginet phpmyadmin