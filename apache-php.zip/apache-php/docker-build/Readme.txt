### must do this stept to add msqli extension

# run the commands to build and run the Docker image:

$ docker build -t myphp:v1 .

How to install more PHP extensions

Many extensions are already compiled into the image, so it's worth checking the output of php -m or php -i before going through the effort of compiling more.

We provide the helper scripts docker-php-ext-configure, docker-php-ext-install, and docker-php-ext-enable to more easily install PHP extensions.

In order to keep the images smaller, PHP's source is kept in a compressed tar file. To facilitate linking of PHP's source with any extension, we also provide the helper script docker-php-source to easily extract the tar or delete the extracted source. Note: if you do use docker-php-source to extract the source, be sure to delete it in the same layer of the docker image.
check this link for php extension install
https://github.com/mlocati/docker-php-extension-installer
===================
Code:
===
FROM php:7.2-apache
RUN docker-php-ext-install mysqli  # install php mysqli modeule
CMD ["apache2-foreground"]
===
Code end:

==================== temp fix =====================
If you are on Docker...

Inside php-container RUN:

#docker-php-ext-install mysqli

#apachectl restart

